package com.app.quantitymanagementapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuantitymanagementappApplicationTests {

	@Test
	void contextLoads() {
	}

}
