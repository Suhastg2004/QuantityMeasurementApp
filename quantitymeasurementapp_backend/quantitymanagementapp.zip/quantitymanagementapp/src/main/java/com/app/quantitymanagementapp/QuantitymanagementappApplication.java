package com.app.quantitymanagementapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuantitymanagementappApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuantitymanagementappApplication.class, args);
	}

}
